/**
 * Created by erinsasha on 12/11/17.
 */

var scripts_path = [
    "/js/er_inj.js",
];

for(var i= 0, script; i<scripts_path.length; i++) {
    script=document.createElement('script');
    script.type='text/javascript';
    script.src=chrome.extension.getURL(scripts_path[i]);
    console.log('trying to add script = '+scripts_path[i]);
    document.head.appendChild(script);
    console.log('script added');
}

var style=document.createElement('link');
style.type='text/css';
style.rel='stylesheet';
style.href=chrome.extension.getURL("/styles/er_inj.css");
document.head.appendChild(style);