console.log("ERLHSERVER is HERE");
var erlhserver = window.erlhserver || {
        init: function () {
            this.started || (console.log("ERLHSERVER START INIT"), this.started = !0, this.createResponseCont(), this.initObserverForErlhRequestCont(), this.requests = {}, console.log("ERLHSERVER is INITED"))
        }, createResponseCont: function () {
            console.log("ERLHSERVER START createResponseCont"), this.elResponseCont = document.createElement("div"), this.elResponseCont.id = "erlh-server-response", this.elResponseCont.hidden = !0, document.body.appendChild(this.elResponseCont), console.log("ERLHSERVER END createResponseCont")
        }, writeMessage: function (e, t) {
            console.log("START ERLH-SERVER writeMessage ID=" + e);
            var o = document.createElement("div");
            o.id = e, o.innerText = JSON.stringify(t), this.elResponseCont.appendChild(o), console.log("END ERLH-SERVER writeMessage ID=" + e)
        }, readMessage: function (e) {
            console.log("START ERLH-SERVER readMessage ID=" + e);
            var t = document.getElementById(e), o = JSON.parse(t.innerText);
            return t.remove(), console.log(o), console.log("END ERLH-SERVER readMessage ID=" + e), o
        }, executeMessage: function (e) {
            var t = this.readMessage(e);
            this.send(t, {id: e})
        }, waitForErlhRequestCont: function (e, t) {
            if (t || (t = 0), console.log("START ERLH-SERVER waitForErlhRequestCont"), this.elRequestCont = document.getElementById("erlh-server-request"), this.elRequestCont) e(this.elRequestCont); else {
                300 == t && alert('One of your extensions disrupts connection with Linked Helper server!!! \nPlease, disable it and reload the page.\n\n Click 3-dots or the orange button at the top right of Chrome window -> "More tools" -> "Extensions"\n\nThen disable all other extensions. \n\nIf it doesn\'t help, please contact us info@linkedhelper.com');
                var o = this;
                setTimeout(function () {
                    o.waitForErlhRequestCont(e, t + 1)
                }, 100)
            }
        }, initObserverForErlhRequestCont: function () {
            if (console.log("START ERLH-SERVER initObserverForErlhRequestCont"), !this.elRequestCont)return void this.waitForErlhRequestCont(this.initObserverForErlhRequestCont.bind(this));
            this.readAllRequests();
            var e = new MutationObserver(this.observerErlhRequestCont.bind(this));
            e.observe(this.elRequestCont, {
                attributes: !1,
                childList: !0,
                characterData: !1
            }), console.log("END ERLH-SERVER initObserverForErlhRequestCont")
        }, observerErlhRequestCont: function (e) {
            this.readAllRequests()
        }, readAllRequests: function () {
            console.log("START ERLH-SERVER readAllRequests");
            for (var e, t = this.elRequestCont.childNodes, o = 0; o < t.length; o++) {
                e = t[o];
                try {
                    this.executeMessage(e.id)
                } catch (e) {
                    console.log("ERLH-SERVER ERROR executeMessage:"), console.error(e)
                }
            }
            console.log("END ERLH-SERVER readAllRequests")
        }, send: function (e, t) {
            console.log("ERLHSERVER START Send"), console.log(e), console.log(t);
            var o = e.method ? e.method : "POST", s = e.requestHeader ? e.requestHeader : {};
            s["Content-Type"] = s["Content-Type"] ? s["Content-Type"] : "application/json;charset=UTF-8";
            var n = this, r = new XMLHttpRequest;
            r.open(o, e.url);
            for (var l, i, R = Object.keys(s), a = 0; a < R.length; a++)l = R[a], i = s[l], r.setRequestHeader(l, i);
            r.onreadystatechange = function () {
                if (r.readyState == XMLHttpRequest.DONE) {
                    console.log("internal_options"), console.log(t), console.log("external_options"), console.log(e);
                    var o = {status: r.status, responseText: r.responseText};
                    console.log("result"), console.log(o), n.writeMessage(t.id, o)
                }
            }, r.send(e.request), console.log("ERLHSERVER END Send")
        }
    };
erlhserver.init();