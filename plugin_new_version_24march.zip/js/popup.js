function add_links() {
    var e = $("#links_block");
    e.append($(build_links_this_tool_can())), e.append($(build_links_main_feature())), e.append($(build_links_important()))
}
function build_links_important() {
    var e = [{
        text: "HOW TO NOT LOSE YOUR DATA",
        url: "https://medium.com/linked-helper/important-linked-helper-data-storage-2a8d73a38e0d"
    }, {
        text: "How To backup & restore your Linked Helper Data",
        url: "https://medium.com/linked-helper/how-to-backup-restore-your-linked-helper-data-f832fdfcc334"
    }, {
        text: "Recommended daily limits",
        url: "https://medium.com/linked-helper/what-kind-of-limits-should-i-use-88df661c6cf0?source=---------6-----------"
    }, {text: "HOW TO", url: "https://medium.com/linked-helper/tagged/how-to"}, {
        text: "FAQ",
        url: "https://medium.com/linked-helper/tagged/faq"
    }, {
        text: "Solutions for common issues",
        url: "https://medium.com/linked-helper/solutions-for-common-issues-75047b5d1e2e"
    }], t = '<div id="links_important" style="font-weight: bold; margin-top: 1em; margin-bottom: 1em">';
    return t += "<p>Please read carefully:</p>", t += build_href_list(e, !0), t += "</div>"
}
function build_links_this_tool_can() {
    var e = [{
        text: "Automatically send personalised invitations (connection requests) to targeted 2nd & 3rd contacts",
        url: "https://medium.com/linked-helper/collect-select-invite-2nd-3rd-linkedin-connections-4f9d41628467"
    }, {
        text: "Send personalized messages and message sequences to 1st connections",
        url: "https://medium.com/linked-helper/how-to-send-your-messages-to-your-linkedin-1st-connections-mailing-system-message-broadcast-8d6d0308516e"
    }, {
        text: "Export your contacts into CSV file for Google Sheet or Microsoft Excel",
        url: "https://medium.com/linked-helper/export-your-contacts-to-csv-file-build-mailing-list-only-for-new-linkedin-interface-2c0327b18716"
    }, {
        text: "Endorse your contacts to get endorsements in return",
        url: "https://medium.com/linked-helper/boost-your-profile-and-get-hundreds-of-endorsements-from-other-users-in-no-time-automatically-b75758237a0f"
    }, {
        text: "Automatically add your signature to manually created messages",
        url: "https://medium.com/linked-helper/automatically-add-your-signature-to-new-messages-61574a394b02"
    }, {
        text: "Profiles auto-visiting",
        url: "https://medium.com/linked-helper/auto-visit-profiles-to-get-look-back-8fe2aa4be7a9"
    }, {
        text: "Sent pending invites bulk canceller",
        url: "https://medium.com/linked-helper/how-to-cancel-withdraw-all-my-sent-pending-invites-connection-requests-in-linkedin-39b8be9ba3ad?source=---------0-----------"
    }], t = '<div id="links_important" style="font-weight: bold; margin-top: 1em; margin-bottom: 1em">';
    return t += "<p>This tool can:</p>", t += build_href_list(e, !1), t += "</div>"
}
function build_links_main_feature() {
    var e = [{
        text: "How to send your messages to your LinkedIn 1st connections",
        url: "https://medium.com/linked-helper/how-to-send-your-messages-to-your-linkedin-1st-connections-mailing-system-message-broadcast-8d6d0308516e"
    }, {
        text: "How to manage Collected Recipients (Recipients Queue), Processed Recipients and Excluded Contacts for message broadcast to 1st connections",
        url: "https://medium.com/linked-helper/how-to-manage-collected-recipients-recipients-queue-processed-recipients-and-excluded-contacts-580d53f6ee63"
    }, {
        text: "How to manage broadcasts to LinkedIn 1st connections - creating messages chains",
        url: "https://medium.com/linked-helper/how-to-manage-broadcasts-to-linkedin-1st-connections-creating-messages-chains-61f746389009"
    }, {
        text: "How to send messages to recently added connections",
        url: "https://medium.com/linked-helper/how-to-collect-all-your-1st-connections-for-message-broadcast-f4b178928759"
    }, {
        text: "How to collect all 1st connections",
        url: "https://medium.com/linked-helper/how-to-collect-all-your-1st-connections-for-message-broadcast-f4b178928759"
    }], t = '<div id="links_important" style="font-weight: bold; margin-top: 1em; margin-bottom: 1em">';
    return t += "<p>You can create Message sequences:</p>", t += build_href_list(e, !1), t += "</div>"
}
function build_href_list(e, t) {
    for (var o, n = '<ul style="list-style-type: none; padding-left: 0em;">', i = 0, s = 1; i < e.length; i++, s++)o = e[i], n += "<li>" + s + ") " + build_href(o.url, o.text, t) + "</li>";
    return n += "</ul>"
}
function build_href(e, t, o) {
    var n;
    return n = o ? 'style="color: red; font-weight: bold"' : "", '<a href="' + e + '" target="_blank" ' + n + ">" + t + "</a>"
}
console.log("my popup js");
var _gaq = _gaq || [];
_gaq.push(["_setAccount", "UA-90253398-1"]), _gaq.push(["_trackPageview"]), function () {
    var e = document.createElement("script");
    e.type = "text/javascript", e.async = !0, e.src = "https://ssl.google-analytics.com/ga.js";
    var t = document.getElementsByTagName("script")[0];
    t.parentNode.insertBefore(e, t), add_links()
}();
var jim = {
    CONST_DEFAULT_SALES_MODE: "DEFAULT", sales_modes: {}, init: function () {
        localStorage.jim_country_code && "" != localStorage.jim_country_code && "undefined" != localStorage.jim_country_code ? this.setup_country_code_and_sale(localStorage.jim_country_code) : this.request_position()
    }, request_position: function () {
        $.getJSON("https://freegeoip.net/json/?callback=?", this.on_request_position.bind(this))
    }, setup_country_code_and_sale: function (e) {
        var t = $("body");
        t.attr("data-country_code", e), t.attr("data-sale-mode", this.get_sale_by_country_code(e))
    }, get_sale_by_country_code: function (e) {
        var t = this.sales_modes[e];
        return t ? t : this.CONST_DEFAULT_SALES_MODE
    }, on_request_position: function (e) {
        console.log(e), this.on_country_code_defined(e.country_code)
    }, on_country_code_defined: function (e) {
        localStorage.jim_country_code = e, this.setup_country_code_and_sale(e)
    }
};
jim.init();