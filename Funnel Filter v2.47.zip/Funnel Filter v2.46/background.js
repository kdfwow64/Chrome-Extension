/* START: FUNCTIONS */
var addOrReplaceParam = function(url, param, value) {
	param = encodeURIComponent(param);
	var r = "([&?]|&amp;)" + param + "\\b(?:=(?:[^&#]*))*";
	var a = document.createElement("a");
	var regex = new RegExp(r);
	var str = param + "=" + encodeURIComponent(value);
	a.href = url;
	var q = a.search.replace(regex, "$1"+str);
	if (q === a.search) {
		a.search += (a.search ? "&" : "") + str;
	} else {
		a.search = q;
	}
	return a.href;
}

function convertToServerTimeZone() {
	offset = -5.0; /* EST UTC - 5 */
	clientDate = new Date();
	utc = clientDate.getTime() + (clientDate.getTimezoneOffset() * 60000);
	serverDate = new Date(utc + (3600000*offset));
	return serverDate;
}
/* END: FUNCTIONS */

/* ON INSTALL TASKS */
chrome.runtime.onInstalled.addListener(function (object)
{
	chrome.storage.local.get([
		"ProfileDB"
	], function(CS) {
		if(!CS["ProfileDB"]) {
			chrome.storage.local.set({
				"UserType": "",
				
				"DailyVisitLimit": 800,
				"TodayVisits": 0,
				"SkipTime": 15,
				
				"ProfileDB": [],
				"CurrentTask": "",
				"ResultFound": 1000,
				"LikeStart": "NONE",
				"LikeList": ""
			});
		}
	});
});

/* PAUSE BEFORE CLOSE */
chrome.windows.onRemoved.addListener(function(windowId) {
	chrome.storage.local.get([
		"BotStatus",
		"ProcessingWindow"
	], function(CS) {
		if(CS["BotStatus"] == "Processing" && CS["ProcessingWindow"] == windowId) {
			chrome.storage.local.set({
				"BotStatus": "Paused",
				"ProcessingWindow": ""
			});
		}
	});
});

onload = function() {
	chrome.storage.local.get([
		"BotStatus"
	], function(CS) {
		if(CS["BotStatus"] == "Processing") {
			chrome.storage.local.set({
				"BotStatus": "Paused",
				"ProcessingWindow": ""
			});
		}
	});
};

/* BACKGROUND TASK MANAGER */
function BackgroundTaskManager() {
	chrome.storage.local.get([
		"TaskStatus",
		"BotStatus",
		"ProfileDB",
		"CurrentTask",
		"SearchValue",
		"ProcessingWindow",
		"DailyVisitLimit",
		"DailyVisitLimitReset",
		"TodayVisits"
	], function(CS) {
		if(CS["CurrentTask"]) var Data = CS["ProfileDB"][CS["CurrentTask"]];

		var TargetAmount = "";
		var DoneAmount = "";
		if(Data) {
			TargetAmount = Data.TargetAmount;
			DoneAmount = Data.Profiles.length;
		}
		
		/* DAILY LIMIT RESET */
		if(convertToServerTimeZone().getHours() >= 17 && Number(CS["DailyVisitLimitReset"]) != convertToServerTimeZone().getDate()) {
			chrome.storage.local.set({
				"TodayVisits": 0,
				"DailyVisitLimitReset": convertToServerTimeZone().getDate()
			});
		}
		
		/* PAUSE WHEN LIMIT CROSSING */
		if(Number(CS["TodayVisits"]) >= Number(CS["DailyVisitLimit"])) {
			chrome.storage.local.set({
				"BotStatus": "Paused"
			});
		}
		
		/* FINISH WHEN LIST END */
		if(CS["TaskStatus"] == "LISTEND") {
			chrome.storage.local.set({
				"TaskStatus": "NONE",
				"BotStatus": "Done"
			});
		}

		/* WINDOW CHECKER */
		if(CS["BotStatus"] == "Processing") {
			var ProcessingWindow = Number(CS["ProcessingWindow"]);
			//alert(ProcessingWindow);
			chrome.windows.get(ProcessingWindow, function(window){
				if(!chrome.runtime.lastError) {
					if(window.state == "minimized") {
						chrome.windows.update(ProcessingWindow, {
							focused: true,
							state: "maximized"
						});
						chrome.windows.update(ProcessingWindow, {
							focused: false
						});
					}
				}
			});
		}
	});
}
BackgroundTaskManager();
setInterval(BackgroundTaskManager, 1000);

/* START OR RESUME TASK */
function StartTask() {
	chrome.storage.local.get([
		"ProfileDB",
		"CurrentTask"
	], function(CS) {
		var Data = CS["ProfileDB"][CS["CurrentTask"]];
		var DoneAmount = Data.Profiles.length;
		
		if(Data.SearchURL.search("linkedin.com/search") != -1) {
			var ResPerPage = 10;
			var PageNo = Math.ceil((DoneAmount + 1) / ResPerPage);
			var SearchURL = addOrReplaceParam(Data.SearchURL, "page", PageNo);
		}
		if(Data.SearchURL.search("linkedin.com/sales") != -1) {
			var ResPerPage = 25;
			var StartFrom = Math.floor((DoneAmount) / ResPerPage) * ResPerPage;
			var SearchURL = addOrReplaceParam(Data.SearchURL, "start", StartFrom);
		}
		
		chrome.windows.create({
			url: SearchURL,
			state: "maximized",
			type: "popup",
			focused: true
		}, function(window) {
			/* SET WINDOW ID */
			var ProcessingWindow = window.id;
			var ProcessingTab = window.tabs[0].id;
			chrome.storage.local.set({
				"ProcessingWindow": ProcessingWindow,
				"ProcessingTab": ProcessingTab
			});
			chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
				if(tabId == ProcessingTab && changeInfo.url) {
					if(SearchURL.search("linkedin.com/search") != -1) chrome.tabs.executeScript(ProcessingTab, {
						file: "RegularVisitor.js"
					});
					if(SearchURL.search("linkedin.com/sales") != -1) chrome.tabs.executeScript(ProcessingTab, {
						file: "SalesNavVisitor.js"
					});
				}
			});
			chrome.windows.update(ProcessingWindow, {
				focused: false
			});
		});
	});
}

/* ON MESSAGE LISTENER */
chrome.extension.onMessage.addListener(function(Request, Sender, SendResponse) {
	if(Request.Message === "StartTask") {
		var TaskID = Request.TaskID;
		chrome.storage.local.set({
			"CurrentTask": TaskID,
			"BotStatus": "Processing"
		}, function() {
			StartTask();
		});
	}
});