var Scroller = setInterval(function(){
	window.scroll(0, this.pageYOffset + 25);
}, 25);

function LikePost(No) {
	var No = No;
	setTimeout(function() {
		chrome.storage.local.get([
			"LikeList",
			"TotalLiked",
			"Connections"
		], function(CS) {
			var Article = document.querySelectorAll("article .feed-s-update__scroll");
			if(Article[No]) {
				var Actor = (Article[No].querySelectorAll("div.feed-s-post-meta > a[data-control-name=\"actor\"]")[0]) ? Article[No].querySelectorAll("div.feed-s-post-meta > a[data-control-name=\"actor\"]")[0].href.split("/")[4] : "";
				var LikeButton = Article[No].querySelectorAll(".feed-s-social-action-bar button.like-button");
				if(LikeButton[0] && Actor) {
					if(CS["Connections"] == "SelectedContacts") {
						if((LikeButton[0].className).search("active") == -1 && (CS["LikeList"]).search(Actor) != -1) {
							LikeButton[0].click();
							var TotalLiked = CS["TotalLiked"] + 1;
							chrome.storage.local.set({"TotalLiked": TotalLiked});
							LikePost(No + 1);
						} else LikePost(No + 1);
					} else {
						if((LikeButton[0].className).search("active") == -1) {
							LikeButton[0].click();
							var TotalLiked = CS["TotalLiked"] + 1;
							chrome.storage.local.set({"TotalLiked": TotalLiked});
							LikePost(No + 1);
						} else LikePost(No + 1);
					}
				} else LikePost(No + 1);
			} else {
				chrome.storage.local.set({
					"TaskStatus": "NONE",
					"BotStatus": "Done"
				});
				window.close();
			}
		});
	}, 1250);
}

LikePost(0);