/* SET TIMEOUT TO RELOAD PAGE */
chrome.storage.local.get([
	"BotStatus"
], function(CS) {
	if(CS["BotStatus"] == "Processing") {
		setTimeout(function(){
			window.location.reload();
		}, 20*1000);
	}
});

/* START: FUNCTIONS */
function getUnixFromTime(DateTime) {
	var NewDate = new Date(DateTime);
	return NewDate.getTime();
}

function isEmpty(value) {
	return (value == null || value.length === 0);
}

function isHidden(el) {
	if(el) return (el.offsetParent === null);
}

function ReportCrash(URL) {
	chrome.storage.local.set({
		"ReportCrash": URL
	});
}

var addOrReplaceParam = function(url, param, value) {
	param = encodeURIComponent(param);
	var r = "([&?]|&amp;)" + param + "\\b(?:=(?:[^&#]*))*";
	var a = document.createElement("a");
	var regex = new RegExp(r);
	var str = param + (value ? "=" + encodeURIComponent(value) : ""); 
	a.href = url;
	var q = a.search.replace(regex, "$1"+str);
	if (q === a.search) {
		a.search += (a.search ? "&" : "") + str;
	} else {
		a.search = q;
	}
	return a.href;
}

function AddZero(num) {
	return (num >= 0 && num < 10) ? "0" + num : num + "";
}

document.addEventListener("DOMContentLoaded", function () {
	if (!Notification) {
		alert("Desktop notifications not available in your browser. Try Google Chrome.");
		return;
	}
	if (Notification.permission !== "granted")
		Notification.requestPermission();
});

function insertAfter(referenceNode, newNode) {
	referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
}

function notifyOnce(DoneAmount) {
	if (Notification.permission !== "granted")
		Notification.requestPermission();
	else {
		var NIcon = chrome.extension.getURL('images/logo.png');
		var NBody = "Amount of visited profile(s): " + DoneAmount;
		var notification = new Notification('Task Completed Successfully!', {
			icon: NIcon,
			body: NBody,
		});

		notification.onclick = function () {
			window.open("");
		};
	}
}

function getAllUserData() {
	chrome.storage.local.get([
		"ProfileDB",
		"CurrentTask"
	], function(CS) {
		var ProfileDB = CS["ProfileDB"];
		var CurrentTask = CS["CurrentTask"];
		var InUser = document.querySelectorAll(".search-result .search-result__info .search-result__result-link");
		var CurrentList = [];
		for(var i=0; i<InUser.length; i++) {
			ProfileURL = InUser[i].href;
			if(ProfileURL.search("linkedin.com/in") != -1) {
				CurrentList.push({
					"URL": ProfileURL
				});
			} else {
				CurrentList.push({
					"URL": "https://www.linkedin.com/in/unavailable/"
				});
			}
		}
		ProfileDB[CurrentTask].CurrentList = CurrentList;
		chrome.storage.local.set({
			"ProfileDB": ProfileDB
		});
	});
	return true;
}

function scanAllUserData() {
	chrome.storage.local.get([
		"ProfileDB",
		"CurrentTask"
	], function(CS) {
		var ProfileDB = CS["ProfileDB"];
		var CurrentTask = CS["CurrentTask"];
		var InUser = document.querySelectorAll(".search-result .search-result__info");
		var CurrentList = [];
		for(var i=0; i<InUser.length; i++) {
			var FullName = (InUser[i].querySelector(".name")) ? InUser[i].querySelector(".name").innerText : "LinkedIn User";
			var Headline = (InUser[i].querySelector(".subline-level-1")) ? InUser[i].querySelector(".subline-level-1").innerText : "";
			var Location = (InUser[i].querySelector(".subline-level-2")) ? InUser[i].querySelector(".subline-level-2").innerText : "";
			var ProfileURL = (InUser[i].querySelector(".search-result__result-link")) ? InUser[i].querySelector(".search-result__result-link").href : "https://www.linkedin.com/in/unavailable/";
			var ProPicURL = (document.querySelectorAll(".search-result .search-result__image img").length > 0) ? document.querySelectorAll(".search-result .search-result__image img")[i].getAttribute("src") : "https://static.licdn.com/scds/common/u/images/themes/katy/ghosts/person/ghost_person_100x100_v1.png";
			var VisitDate = Date();
			var ProfileData = {
				"FullName": FullName,
				"Email": "",
				"Phone": "",
				"IM": "",
				"Twitter": "",
				"Headline": Headline,
				"Location": Location,
				"ProPicURL": ProPicURL,
				"URL": ProfileURL,
				"SkillList": "",
				"Experience": [],
				"Education": [],
				"VisitDate": VisitDate
			};
			if(ProfileDB[CurrentTask].Profiles.push(ProfileData)) ProfileDB[CurrentTask].TotalVisited = Number(ProfileDB[CurrentTask].TotalVisited) + 1;
		}
		chrome.storage.local.set({
			"ProfileDB": ProfileDB
		});
	});
	return true;
}

function ScrapProfileData() {
	var VisuallyHidden = document.getElementsByClassName("visually-hidden");
	for(var i=0; i<VisuallyHidden.length; i++) VisuallyHidden[i].innerHTML = "";

	/* FULL NAME */
	var FullName = (document.querySelectorAll(".pv-top-card-section__name")[0]) ? document.querySelectorAll(".pv-top-card-section__name")[0].innerText.trim() : "LinkedIn User";
	
	/* URL */
	var ProfileURL = "https://" + window.location.hostname + window.location.pathname;

	/* SKILLS */
	var Skills = document.querySelectorAll(".pv-skill-entity__skill-name");
	var SkillList = "";
	if(Skills[0]) {
		for(var i=0; i<Skills.length; i++) {
			if(i == 0) {
				SkillList = Skills[i].innerText.trim();
			} else {
				SkillList = SkillList + " , " + Skills[i].innerText.trim();
			}
		}
	}

	/* LOCATION */
	var Location = (document.querySelectorAll(".pv-top-card-section__location")[0]) ? document.querySelectorAll(".pv-top-card-section__location")[0].innerText.trim() : "";
	
	/* HEADLINE */
	var Headline = (document.querySelectorAll(".pv-top-card-section__headline")[0]) ? document.querySelectorAll(".pv-top-card-section__headline")[0].innerText.trim() : "";

	/* PRO PIC URL */
	var ProPic = document.querySelectorAll(".pv-top-card-section__photo img");
	var ProPicURL = "";
	if(ProPic[0]) ProPicURL = ProPic[0].getAttribute("src");;
	if(isEmpty(ProPicURL)) ProPicURL = "https://static.licdn.com/scds/common/u/images/themes/katy/ghosts/person/ghost_person_100x100_v1.png";
	
	/* EMAIL */
	var Email = (document.querySelectorAll(".pv-contact-info .ci-email .pv-contact-info__ci-container")[0]) ? document.querySelectorAll(".pv-contact-info .ci-email .pv-contact-info__ci-container")[0].innerText.trim() : "";
	
	/* PHONE */
	var Phone = (document.querySelectorAll(".pv-contact-info .ci-phone .pv-contact-info__ci-container")[0]) ? document.querySelectorAll(".pv-contact-info .ci-phone .pv-contact-info__ci-container")[0].innerText.trim() : "";

	/* IM */
	var IM = (document.querySelectorAll(".pv-contact-info .ci-ims .pv-contact-info__ci-container")[0]) ? document.querySelectorAll(".pv-contact-info .ci-ims .pv-contact-info__ci-container")[0].innerText.trim() : "";
	
	/* TWITTER */
	var Twitter = (document.querySelectorAll(".pv-contact-info .ci-twitter .pv-contact-info__ci-container")[0]) ? document.querySelectorAll(".pv-contact-info .ci-twitter .pv-contact-info__ci-container")[0].innerText.trim() : "";
	
	/* VISIT DATE */
	var VisitDate = Date();

	var ProfileData = {
		"FullName": FullName,
		"Email": Email,
		"Phone": Phone,
		"IM": IM,
		"Twitter": Twitter,
		"Headline": Headline,
		"Location": Location,
		"ProPicURL": ProPicURL,
		"URL": ProfileURL,
		"SkillList": SkillList,
		"Experience": [],
		"Education": [],
		"VisitDate": VisitDate
	};

	/* EXPERIENCES */
	var Experience = document.querySelectorAll(".experience-section .pv-entity__summary-info");
	for(var i=0; i<Experience.length; i++) {
		var Position = (Experience[i].querySelectorAll("h3")[0]) ? Experience[i].querySelectorAll("h3")[0].innerText.trim() : "";
		var CompanyName = (Experience[i].querySelectorAll("h4")[0]) ? Experience[i].querySelectorAll("h4")[0].innerText.trim() : "";
		var DateRange = (Experience[i].querySelectorAll("h4")[1]) ? Experience[i].querySelectorAll("h4")[1].innerText.trim() : "";
		var StartDate = (DateRange.split("–")[0]) ? DateRange.split("–")[0].trim() : "";
		var EndDate = (DateRange.split("–")[1]) ? DateRange.split("–")[1].trim() : "";
		var Location = (Experience[i].querySelectorAll("h4")[3]) ? Experience[i].querySelectorAll("h4")[3].innerText.trim() : "";
		var ExperienceData = {
			"CompanyName": CompanyName,
			"Position": Position,
			"StartDate": StartDate,
			"EndDate": EndDate,
			"Location": Location
		};
		ProfileData.Experience.push(ExperienceData);
	}
	
	/* EDUCATION */
	var Education = document.querySelectorAll(".education-section .pv-entity__summary-info");
	for(var i=0; i<Education.length; i++) {
		var Institute = (Education[i].querySelectorAll(".pv-entity__school-name")[0]) ? Education[i].querySelectorAll(".pv-entity__school-name")[0].innerText.trim() : "";
		var Degree = (Education[i].querySelectorAll(".pv-entity__degree-name")[0]) ? Education[i].querySelectorAll(".pv-entity__degree-name")[0].innerText.trim() : "";
		var DateRange = (Education[i].querySelectorAll(".pv-education-entity__date")[0]) ? Education[i].querySelectorAll(".pv-education-entity__date")[0].innerText.trim() : "";
		var StartDate = (DateRange.split("–")[0]) ? DateRange.split("–")[0].trim() : "";
		var EndDate = (DateRange.split("–")[1]) ? DateRange.split("–")[1].trim() : "";
		EducationData = {
			"Institute": Institute,
			"Degree": Degree,
			"StartDate": StartDate,
			"EndDate": EndDate
		};
		ProfileData.Education.push(EducationData);
	}

	return ProfileData;
}
/* END: FUNCTIONS */

/* START: GLOBAL VARIABLES */
var PageURL = window.location.href;
var ResPerPage = 10;
/* END: GLOBAL VARIABLES */

/* MAIN TASK MANAGER */
function MainTaskManager() {
	chrome.storage.local.get([
		"ProfileDB",
		"CurrentTask",
		"BotStatus"
	], function(CS) {
		if(CS["BotStatus"] == "Processing") {
			var Data = CS["ProfileDB"][CS["CurrentTask"]];
			var TargetAmount = Data.TargetAmount;
			var DoneAmount = Data.TotalVisited;
			
			/* STOP IF TARGET REACHED */
			if(DoneAmount >= TargetAmount) {
				chrome.storage.local.set({
					"BotStatus": "Done"
				});
				notifyOnce(DoneAmount);
			}
			
			/* STOP IF LIST END */
			if(document.getElementsByClassName("search-results__total").length > 0) {
				var TotalResFound = document.getElementsByClassName("search-results__total")[0].innerText.replace(/[^0-9]/g,'');
				if(TotalResFound == 0 || DoneAmount >= TotalResFound) {
					chrome.storage.local.set({
						"BotStatus": "Done"
					});
					notifyOnce(DoneAmount);
				}
			}
		}
	});
}
MainTaskManager();
setInterval(MainTaskManager, 1000);

/* CONTINUE VISITING PROFILES */
function ContinueVisiting(Position) {
	var Position = Position;
	chrome.storage.local.get([
		"ProfileDB",
		"CurrentTask",
		"TodayVisits",
		"SkipTime"
	], function(CS) {
		var Data = CS["ProfileDB"][CS["CurrentTask"]];
		var CurrentList = Data.CurrentList;
		var ListPosition = Data.TotalVisited % ResPerPage;
		if(Position == "FromZero" || ListPosition != 0) {
			var NextURL = CurrentList[ListPosition].URL;
			var Skipable = 0;
			for(var i=0; i<CS["ProfileDB"].length; i++) {
				if(CS["ProfileDB"][i].TaskType == "Visit") for(var n=0; n<CS["ProfileDB"][i].Profiles.length; n++) {
					var URL = CS["ProfileDB"][i].Profiles[n].URL;
					var CurrentTime = new Date().getTime();
					var VisitDate = getUnixFromTime(CS["ProfileDB"][i].Profiles[n].VisitDate) + (Number(CS["SkipTime"]) * 24 * 60 * 60 * 1000);
					if(URL == NextURL && (VisitDate + (Number(CS["SkipTime"]) * 24 * 60 * 60 * 1000)) > CurrentTime) Skipable = 1;
				}
			}
			if(Skipable == 1) {
				var ProfileDB = CS["ProfileDB"];
				var CurrentTask = CS["CurrentTask"];
				ProfileDB[CurrentTask].TotalVisited = Number(ProfileDB[CurrentTask].TotalVisited) + 1;
				chrome.storage.local.set({
					"ProfileDB": ProfileDB
				}, function() {
					ContinueVisiting("");
				});
			} else {
				window.location.href = NextURL;
			}
		} else {
			var SearchURL = addOrReplaceParam(Data.SearchURL, "page", Math.ceil((Data.TotalVisited + 1)/ResPerPage));
			window.location.href = SearchURL;
		}
	});
}

/* RESULT PAGE */
function SaveCurrentList() {
	chrome.storage.local.get([
		"ProfileDB",
		"CurrentTask"
	], function(CS) {
		var Data = CS["ProfileDB"][CS["CurrentTask"]];
		var ListPosition = Data.TotalVisited % ResPerPage;

		if(Data.TaskType == "Scan") {
			if(scanAllUserData()) {
				setTimeout(function(){
					ContinueVisiting("");
				}, 1000);
			}
		}
		
		if(Data.TaskType == "Visit") {
			if(ListPosition == 0) {
				if(getAllUserData()) {
					setTimeout(function(){
						ContinueVisiting("FromZero");
					}, 1000);
				}
			} else {
				ContinueVisiting("");
			}

		}
	});
}

/* SAVE PROFILE DATA */
function SaveProfileData() {
	chrome.storage.local.get([
		"ProfileDB",
		"CurrentTask",
		"TodayVisits"
	], function(CS) {
		var ProfileDB = CS["ProfileDB"];
		var CurrentTask = CS["CurrentTask"];
		
		if(ProfileDB[CurrentTask].Profiles.push(ScrapProfileData())) {
			ProfileDB[CurrentTask].TotalVisited = Number(ProfileDB[CurrentTask].TotalVisited) + 1;
			var TodayVisits = Number(CS["TodayVisits"]) + 1;
			chrome.storage.local.set({
				"ProfileDB": ProfileDB,
				"TodayVisits": TodayVisits
			}, function() {
				ContinueVisiting("");
			});
		}
		
		setTimeout(function() {
			ContinueVisiting("");
		}, 15000);
	});
}

/* CALL DATA LOADER WHEN PAGE LOADED */
chrome.storage.local.get([
	"BotStatus"
], function(CS) {
	var LoadingAnimation = document.getElementsByClassName("initial-load-animation")[0];
	var CatchLoadingAnimation = setInterval(function(){
		if(isHidden(LoadingAnimation) == true) {
			clearInterval(CatchLoadingAnimation);
			if(CS["BotStatus"] == "Processing") setTimeout(function() {
				var Scroller = setInterval(function(){
					window.scroll(0, this.pageYOffset + 15);
				}, 15);
				window.onscroll = function() {
					if((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
						clearInterval(Scroller);
						window.onscroll = function() {};

						if(PageURL.search("linkedin.com/in") != -1) {
							// EXPAND SKILLS
							if(!(document.querySelectorAll(".pv-skill-entity__skill-name").length > 3) && document.querySelectorAll(".pv-skills-section__additional-skills")[0]) {
								document.querySelectorAll(".pv-skills-section__additional-skills")[0].click();
							}
							// EXPAND CONTACT DETAILS
							if(document.querySelector("[data-control-name=contact_see_more]")) {
								document.querySelector("[data-control-name=contact_see_more]").click();
							}
						}

						setTimeout(function(){
							window.scrollTo(0, 0);
							if(PageURL.search("linkedin.com/search") != -1) {
								SaveCurrentList();
							} else if(PageURL.search("linkedin.com/in") != -1) {
								SaveProfileData();
							} else {
								chrome.storage.local.set({
									"BotStatus": "Paused"
								});
								window.location.reload();
							}
						}, 1000);
					}
				};
			}, 1000);
		}
	}, 1000);
});