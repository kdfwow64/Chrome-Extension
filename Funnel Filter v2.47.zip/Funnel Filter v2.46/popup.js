/* START: FUNCTIONS */
function setCookie(cname, cvalue, exhours) {
    var d = new Date();
    d.setTime(d.getTime() + (exhours * 60 * 60 * 1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function ShowMessage(TYPE, TEXT) {
	if(TYPE == "ERROR") var Class = "error-message";
	if(TYPE == "SUCCESS" || TYPE == "LOADING") var Class = "success-message";
	var Message = document.getElementById("Message");
	if(TYPE == "LOADING") Message.innerHTML = TEXT + "<br/><img src=\"images/loading.gif\" width=\"30px\"/>";
	else Message.innerHTML = TEXT;
	Message.setAttribute("class", Class);
	Message.style.display = "inline-block";
}

function AddInterval(FunctionCall, Delay) {
    FunctionCall();
    setInterval(FunctionCall, Delay);
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function timeConverter(t) {     
	var a = new Date(t);
    var today = new Date();
    var yesterday = new Date(Date.now() - 86400000);
    var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = a.getHours();
    var min = a.getMinutes();
    if (a.setHours(0,0,0,0) == today.setHours(0,0,0,0))
        return 'Today, ' + hour + ':' + min;
    else if (a.setHours(0,0,0,0) == yesterday.setHours(0,0,0,0))
        return 'Yesterday, ' + hour + ':' + min;
    else if (year == today.getFullYear())
        return date + ' ' + month + ', ' + hour + ':' + min;
    else
        return date + ' ' + month + ' ' + year + ', ' + hour + ':' + min;
}

var addOrReplaceParam = function(url, param, value) {
	param = encodeURIComponent(param);
	var r = "([&?]|&amp;)" + param + "\\b(?:=(?:[^&#]*))*";
	var a = document.createElement('a');
	var regex = new RegExp(r);
	var str = param + (value ? "=" + encodeURIComponent(value) : ""); 
	a.href = url;
	var q = a.search.replace(regex, "$1"+str);
	if (q === a.search) {
		a.search += (a.search ? "&" : "") + str;
	} else {
		a.search = q;
	}
	return a.href;
}

var getQueryString = function ( field, url ) {
	var href = url ? url : window.location.href;
	var reg = new RegExp( '[?&]' + field + '=([^&#]*)', 'i' );
	var string = reg.exec(href);
	return string ? string[1] : null;
};

function isEmpty(value) {
	return (value == null || value.length === 0);
}

function msToTime(duration) {
	var milliseconds = parseInt((duration%1000)/100)
		, seconds = parseInt((duration/1000)%60)
		, minutes = parseInt((duration/(1000*60))%60)
		, hours = parseInt((duration/(1000*60*60))%24);
	hours = (hours < 10) ? "0" + hours : hours;
	minutes = (minutes < 10) ? "0" + minutes : minutes;
	seconds = (seconds < 10) ? "0" + seconds : seconds;
	return hours + ":" + minutes + ":" + seconds;
}

function getRandomInt(min, max) {
	var min = Number(min);
	var max = Number(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

document.getElementsByAttribute = Element.prototype.getElementsByAttribute = function(attr) {
	var nodeList = this.getElementsByTagName('*');
	var nodeArray = [];
	for (var i = 0, elem; elem = nodeList[i]; i++) {
		if ( elem.getAttribute(attr) ) nodeArray.push(elem);
	}
	return nodeArray;
};

function OpenTab(ClassName) {
	var TabContent = document.getElementsByClassName("TabContent");
	for (i = 0; i < TabContent.length; i++) {
		TabContent[i].style.display = "none";
	}
	document.getElementsByClassName(ClassName)[0].style.display = "block";
	document.getElementById("Message").style.display = "none";
}

function ShowProfile(TaskID, ProfileID, BackPage, VisitDate) {
	chrome.storage.local.get([
		"ProfileDB"
	], function(CS) {
		var Data = CS["ProfileDB"][TaskID].Profiles[ProfileID];
		var ProfilePage = document.querySelector(".ShowProfile");
			ProfilePage.querySelector(".ProPicURL").setAttribute("src", Data.ProPicURL);
			ProfilePage.querySelector(".FullName").innerHTML = Data.FullName;
			ProfilePage.querySelector(".Headline").innerHTML = Data.Headline;
			ProfilePage.querySelector(".Location").innerHTML = Data.Location;
		
		var ContactInfo = ProfilePage.querySelector(".ContactInfo");
			ContactInfo.innerHTML = "";
		if(isEmpty(Data.Email) && isEmpty(Data.Phone) && isEmpty(Data.IM) && isEmpty(Data.Twitter)) {
			ProfilePage.querySelector(".ContactInfoTitile").style.display = "none";
			ContactInfo.style.display = "none";
		}
		if(!isEmpty(Data.Email)) ContactInfo.innerHTML = ContactInfo.innerHTML + "<span>Email: " + Data.Email + "</span><br/>";
		if(!isEmpty(Data.Phone)) ContactInfo.innerHTML = ContactInfo.innerHTML + "<span>Phone: " + Data.Phone + "</span><br/>";
		if(!isEmpty(Data.IM)) ContactInfo.innerHTML = ContactInfo.innerHTML + "<span>IM: " + Data.IM + "</span><br/>";
		if(!isEmpty(Data.Twitter)) ContactInfo.innerHTML = ContactInfo.innerHTML + "<span>Twitter: " + Data.Twitter + "</span><br/>";
		
		var ExperienceList = ProfilePage.querySelector(".Experience");
			ExperienceList.innerHTML = "";
		for(var i=0; i<Data.Experience.length; i++) {
			var Experience = document.createElement("p");
				Experience.style = "margin-top: 0.5em;";
				Experience.innerHTML = "<span style=\"font-size: 100%;\">" + Data.Experience[i].Position + "</span><br/><span style=\"font-size: 75%;\">" + Data.Experience[i].CompanyName + " · " + Data.Experience[i].Location + "</span><br/><span style=\"font-size: 75%;\">" + Data.Experience[i].StartDate + " - " + Data.Experience[i].EndDate + "</span>";
			ExperienceList.appendChild(Experience);
		}
		
		var EducationList = ProfilePage.querySelector(".Education");
			EducationList.innerHTML = "";
		for(var i=0; i<Data.Education.length; i++) {
			var Education = document.createElement("p");
				Education.style = "margin-top: 0.5em;";
				Education.innerHTML = "<span style=\"font-size: 100%;\">" + Data.Education[i].Institute + "</span><br/><span style=\"font-size: 75%;\">" + Data.Education[i].Degree + "</span><br/><span style=\"font-size: 75%;\">" + Data.Education[i].StartDate + " - " + Data.Education[i].EndDate + "</span>";
			EducationList.appendChild(Education);
		}
		
		var SkillList = ProfilePage.querySelector(".SkillList");
			SkillList.innerHTML = Data.SkillList;
		
		if(isEmpty(VisitDate)) {
			var ProfileURL = ProfilePage.querySelector(".ProfileURL");
				ProfileURL.style = "display: inline-block;";
				ProfileURL.setAttribute("href", Data.URL);
		}
		
		if(isEmpty(BackPage)) {
			ProfilePage.querySelector(".ProBack").style.display = "none";
		} else {
			ProfilePage.querySelector(".ProBack").onclick = function() {
				OpenTab(BackPage);
			};
			ProfilePage.querySelector(".ProBack").style.display = "inline-block";
		}
		OpenTab("ShowProfile");
	});
}
/* END: FUNCTIONS */

/* LICENSE VERIFICATION */
function verifyAndSaveLicense(license) {
	var accessLevel = license.accessLevel;
	var createdTime = Number(license.createdTime);
	var licenseInfo = document.getElementById("licenseInfo");
	var BlockUsing = document.getElementById("BlockUsing");
	if(accessLevel == "FREE_TRIAL") {
		var expireOn = createdTime + (86400000 * 30);
		if(expireOn > Date.now()) {
			chrome.storage.local.set({
				"DailyVisitLimit": 500
			});
			licenseInfo.innerHTML = "<span style=\"color: red;\">License Validity: FREE TRIAL (Maximum 500 profile view per day.)</span>";
			if(document.getElementsByName("ExportCSV").length > 0) document.getElementsByName("ExportCSV")[0].setAttribute("name", "ExportCSVDisabled");
			if(document.getElementsByName("ExportCSVDisabled").length > 0) document.getElementsByName("ExportCSVDisabled")[0].onclick = function() {
				ShowMessage("ERROR", "You are using trial version. Please buy full version to export as CSV.");
			};
			if(document.getElementsByName("ExportIT").length > 0) document.getElementsByName("ExportIT")[0].setAttribute("name", "ExportITDisabled");
			if(document.getElementsByName("ExportITDisabled").length > 0) document.getElementsByName("ExportITDisabled")[0].onclick = function() {
				ShowMessage("ERROR", "You are using trial version. Please buy full version to export as CSV.");
			};
		} else {
			if(BlockUsing) BlockUsing.style.display = "block";
		}
	}
	if(accessLevel == "FULL") {
		var expireOn = createdTime + (86400000 * 365);
		if(expireOn > Date.now()) {
			licenseInfo.innerHTML = "<span style=\"color: green;\">License validity: " + timeConverter(expireOn) + "</span>";
		} else {
			BlockUsing.style.display = "block";
		}
	}
}

chrome.identity.getAuthToken({ 'interactive': true }, function(token) {
	var CWS_LICENSE_API_URL = 'https://www.googleapis.com/chromewebstore/v1.1/userlicenses/';
	var req = new XMLHttpRequest();
	req.open('GET', CWS_LICENSE_API_URL + chrome.runtime.id);
	req.setRequestHeader('Authorization', 'Bearer ' + token);
	req.onreadystatechange = function() {
		if (req.readyState == 4) {
			var license = JSON.parse(req.responseText);
			verifyAndSaveLicense(license);
		}
	}
	req.send();
});

/* SHOW A WORKING PAGE */
chrome.storage.local.get([
	"TaskStatus",
	"BotStatus",
	"CurrentTask",
	"SearchValue",
	"SearchURL"
], function(CS) {
	chrome.tabs.query({
		active: true,
		currentWindow: true
	}, function(tabs) {
		var tab = tabs[0];
		var currentURL = tab.url;
		if(CS["BotStatus"] == "Processing" || CS["BotStatus"] == "Paused") {
			OpenTab("ProgressTab");
		} else if (CS["BotStatus"] == "Done") {
			OpenTab("ResultTab");
		} else if (currentURL.search("linkedin.com/search") != -1) {
			OpenTab("StartTab");
			/* ALLOW ONLY PEOPLE TO VISIT */
			if(currentURL.search("/people/") == -1) {
				ShowMessage("ERROR", "Warning! You can only visit profile of people.");
			}
		} else if (currentURL.search("linkedin.com/sales/search\\?") != -1) {
			/* FOR SALES NAV */
			OpenTab("StartTab");
			document.querySelector("[name=StartScanning]").style.display = "none";
		} else if (currentURL.search("linkedin.com/in") == -1) {
			OpenTab("HomePage");
		}
	});
});

/* START TASK PAGE */
chrome.storage.local.get([
	"ProfileDB",
	"BotStatus",
	"SearchValue",
	"ResultFound"
], function(CS) {
	var Data = CS["ProfileDB"];
	chrome.tabs.query({
		active: true,
		currentWindow: true
	}, function(tabs) {
		var tab = tabs[0];
		var CurrentURL = tab.url;
		/* SET TASK NAME */
		document.getElementsByName("TaskName")[0].value = (getCookie("CurrentTaskName")) ? getCookie("CurrentTaskName") : CS["SearchValue"];
		/* SET TARGET AMOUNT */
		document.getElementsByName("TargetAmount")[0].value = (Number(CS["ResultFound"]) < 1000) ? Number(CS["ResultFound"]) : 1000;
	});
});

/* CHECK IF VISITED PROFILE */
chrome.storage.local.get([
	"ProfileDB",
	"BotStatus"
], function(CS) {
	var Data = CS["ProfileDB"];
	chrome.tabs.query({
		active: true,
		currentWindow: true
	}, function(tabs) {
		var tab = tabs[0];
		var CurrentURL = tab.url;
		if(CurrentURL.search("linkedin.com/in") != -1 && CS["BotStatus"] != "Processing") {
			var ProID = CurrentURL.split("/")[4];
			var Found = 0;
			for(var i=0; i<Data.length; i++) {
				for(var n=0; n<Data[i].Profiles.length; n++) {
					if(Data[i].Profiles[n].URL.search(ProID) != -1) {
						ShowProfile(i, n, "", Data[i].Profiles[n].VisitDate);
						Found++;
						break;
					}
				}
			}
			if(Found == 0) OpenTab("HomePage");
		}
	});
});

/* EXPORT TO CSV */
function ExportCSV(RawData) {
	var Data = RawData.Profiles;
	var CSVData = "Task Name:," + RawData.TaskName + "\n" + "Visit Date:," + RawData.Date + " EST\n\n" + "Profile URL,First Name,Last Name,Email,Phone,IM,Twitter,Location,Current Company,Position,Start Date,Skill List,School Name,Degree,Graduation Year";

	for(var i=0; i<Data.length; i++) {
		var URL = (Data[i].URL.search(",") != -1) ? "\"" + Data[i].URL + "\"" : Data[i].URL;
		var FirstName = Data[i].FullName.split(" ")[0];
		if(Data[i].FullName.split(" ")[1]) var LastName = Data[i].FullName.split(" ")[1];
		if(Data[i].FullName.split(" ")[2]) var LastName = Data[i].FullName.split(" ")[1] + " " + Data[i].FullName.split(" ")[2];
		var Location = (Data[i].Location.search(",") != -1) ? "\"" + Data[i].Location + "\"" : Data[i].Location;
		var CompanyName = "";
		var Position = "";
		var StartDate = "";
		var CompanyLocation = "";
		if(Data[i].Experience.length > 0) {
			CompanyName = (Data[i].Experience[0].CompanyName.search(",") != -1) ? "\"" + Data[i].Experience[0].CompanyName + "\"" : Data[i].Experience[0].CompanyName;
			Position = (Data[i].Experience[0].Position.search(",") != -1) ? "\"" + Data[i].Experience[0].Position + "\"" : Data[i].Experience[0].Position;
			StartDate = (Data[i].Experience[0].StartDate.search(",") != -1) ? "\"" + Data[i].Experience[0].StartDate + "\"" : Data[i].Experience[0].StartDate;
			CompanyLocation = (Data[i].Experience[0].Location.search(",") != -1) ? "\"" + Data[i].Experience[0].Location + "\"" : Data[i].Experience[0].Location;
		}
		var SkillList = (Data[i].SkillList.search(",") != -1) ? "\"" + Data[i].SkillList + "\"" : Data[i].SkillList;
		var Degree = "";
		var Institute = "";
		var GraduationYear = "";
		if(Data[i].Education.length > 0) {
			Degree = (Data[i].Education[0].Degree.search(",") != -1) ? "\"" + Data[i].Education[0].Degree + "\"" : Data[i].Education[0].Degree;
			Institute = (Data[i].Education[0].Institute.search(",") != -1) ? "\"" + Data[i].Education[0].Institute + "\"" : Data[i].Education[0].Institute;
			GraduationYear = Data[i].Education[0].StartDate + " - " +  Data[i].Education[0].EndDate;
		}
		var Email = Data[i].Email;
		var Phone = Data[i].Phone;
		var IM = Data[i].IM;
		var Twitter = Data[i].Twitter;
		
		CSVData = CSVData + "\n" + URL + "," + FirstName + "," + LastName + "," + Email + "," + Phone + "," + IM + "," + Twitter + "," + Location + "," + CompanyName + "," + Position + "," + StartDate + "," + SkillList + "," + Institute + "," + Degree + "," + GraduationYear + ",";
	}
	chrome.downloads.download({
		url: 'data:text/plain;charset=utf-8,' + encodeURIComponent(CSVData),
		filename: 'Profile List - ' + RawData.TaskName + '.csv',
		saveAs: true
	});
}

/* TASK HISTORY PAGE */
function ShowSearchResults(ID, NameFilter, LocationFilter, SkillFilter, CompanyFilter, ReturnTo, BackPage) {
	var NameFilter = NameFilter.toLowerCase();
	var LocationFilter = LocationFilter.toLowerCase();
	var SkillFilter = SkillFilter.toLowerCase();
	var CompanyFilter = CompanyFilter.toLowerCase();
	ReturnTo.innerHTML = "";
	chrome.storage.local.get([
		"ProfileDB"
	], function(CS) {
		var Data = CS["ProfileDB"][ID];		
		for(var i=0; i<Data.Profiles.length; i++) {
			var FullName = Data.Profiles[i].FullName;
			var WorkingPlace = (Data.Profiles[i].Experience.length > 0) ? Data.Profiles[i].Experience[0].CompanyName : "";
			var Headline = Data.Profiles[i].Headline;
			var Location = Data.Profiles[i].Location;
			var SkillList = Data.Profiles[i].SkillList;
			var ProPicURL =  Data.Profiles[i].ProPicURL;
			var ProURL =  Data.Profiles[i].URL;
			
			var TaskID = ID;
			var ProfileID = i;

			if((FullName.toLowerCase().search(NameFilter) != -1) && (Location.toLowerCase().search(LocationFilter) != -1) && (WorkingPlace.toLowerCase().search(CompanyFilter) != -1) && (SkillList.toLowerCase().search(SkillFilter) != -1)) {
				var ProID = ProURL.split("/")[4];
				var DataListItem = document.createElement("li");
					DataListItem.setAttribute("TaskID", TaskID);
					DataListItem.setAttribute("ProfileID", ProfileID);
					DataListItem.innerHTML = "<a><div class=\"ProPic\" style=\"width: 45px;\"><img src=\"" + ProPicURL + "\" style=\"width: 45px; height: 45px; border-radius: 22.5px;\"/></div><div class=\"ProBrief\" style=\"width: 215px;\">" + FullName + "<br/><span class=\"ProInfo\">" + Headline + "</span><span class=\"ProInfo\">" + Location + "</span></div></a>";
					DataListItem.onclick = function() {
						ShowProfile(this.getAttribute("TaskID"), this.getAttribute("ProfileID"), BackPage, "");
					};
				ReturnTo.appendChild(DataListItem);
			}
		}
	});
}
function ShowDetails(ID) {
	chrome.storage.local.get([
		"ProfileDB"
	], function(CS) {
		var Data = CS["ProfileDB"][ID];
		OpenTab("TaskDetails");
		
		/* TASK STATUS INFO */
		if(Data.TaskType == "Visit") document.querySelector(".TaskDetails .Status").innerHTML = "<span>Name: " + Data.TaskName + " (<a target=\"_blank\" href=\"" + Data.SearchURL + "\">Search Page</a>)<br/>Target amount of profile to visit: " + Data.TargetAmount + "<br/>Profile visited: " + Data.Profiles.length + "<br/>Profile skipped: " + (Data.TotalVisited - Data.Profiles.length) + " (Already visited)<br/>Date: " + Data.Date + "</span>";
		if(Data.TaskType == "Scan") document.querySelector(".TaskDetails .Status").innerHTML = "<span>Name: " + Data.TaskName + " (<a target=\"_blank\" href=\"" + Data.SearchURL + "\">Search Page</a>)<br/>Target amount of profile to scan: " + Data.TargetAmount + "<br/>Profile scanned: " + Data.Profiles.length + "<br/>Profile skipped: " + (Data.TotalVisited - Data.Profiles.length) + " (Already visited)<br/>Date: " + Data.Date + "</span>";
		
		/* GET QUIRY STRINGS */
		var ReturnTo = document.getElementById("SearchResults");
		ShowSearchResults(ID, "", "", "", "", ReturnTo, "TaskDetails");
		
		/* EXPORT TO CSV */
		if(document.getElementsByName("ExportCSV").length > 0) document.getElementsByName("ExportCSV")[0].onclick = function() {
			ExportCSV(Data);
		}
		
		/* RESUME TASK */
		document.getElementsByName("TaskResume")[0].onclick = function() {
			chrome.extension.sendMessage({
				"Message": "StartTask",
				"TaskID": ID
			});
			OpenTab("ProgressTab");
			document.getElementsByName("ResumeTask")[0].style.display = "none";
		}
	});
}
function TaskHistory() {
	chrome.storage.local.get([
		"ProfileDB",
		"BotStatus"
	], function(CS) {
		var ProfileDB = CS["ProfileDB"];
		
		/* FULL TASK LIST */
		var TaskList = document.querySelector(".TaskList");
			TaskList.innerHTML = "";
		for(var i=ProfileDB.length-1; i>=0; i--) {
			var TaskElement = document.createElement("tr");
			TaskElement.innerHTML = "<td class=\"link\" id=\"" + i + "\">" + ProfileDB[i].TaskName + "</td><td>" + ProfileDB[i].TotalVisited + "</td><td style=\"text-align:right;\">" + ProfileDB[i].Date + "</td><td align=\"right\" target-id=\"" + i + "\" target-action=\"delete\"><img src=\"images/delete.png\" style=\"height: 1em\"/></td>";
			TaskList.appendChild(TaskElement);
			document.getElementById(i).onclick = function() {
				var ID = this.id;
				ShowDetails(ID);
			};
		}
		for(var i=0; i<document.querySelectorAll(".TaskList [target-action=delete]").length; i++) {
			document.querySelectorAll(".TaskList [target-action=delete]")[i].onclick = function() {
				if(CS["BotStatus"] == "Processing") {
					ShowMessage("ERROR", "Please stop the current process to delete history!");
				} else {
					var TargetID = this.getAttribute("target-id");
					var NewProfileDB = [];
					for(var n=0; n<ProfileDB.length; n++) {
						if(n != TargetID) NewProfileDB.push(ProfileDB[n]);
					}
					chrome.storage.local.set({
						"ProfileDB": NewProfileDB,
						"BotStatus": "INACTIVE"
					}, function() {
						ShowMessage("SUCCESS", "History has been removed successfully!");
						TaskHistory();
					});
				}
			}
		}
	});
}

/* CLOSE AT CLICK ON CANCEL BUTTON */
var Cancel = document.getElementsByName("Cancel");
for(var i=0; i<Cancel.length; i++)
{
	Cancel[i].onclick = function() {
		window.close();
	};
}

/* STARTING TASK */
document.querySelector(".StartTask").onsubmit = function() {
	var TaskName = this.TaskName.value;
	var TargetAmount = this.TargetAmount.value;
	var TaskType = this.TaskType.value;
	var TodayDate = new Date().getMonth()+1 + "/" + new Date().getDate() + "/" + new Date().getFullYear();
	if(isEmpty(TaskName)) {
		ShowMessage("ERROR", "Please enter a name.");
	} else if (isEmpty(TargetAmount) || TargetAmount>1000 || TargetAmount==0) {
		ShowMessage("ERROR", "The amount range is 1-1000.");
	} else chrome.storage.local.get([
		"ProfileDB",
		"SearchURL"
	], function(CS) {
		var ProfileDB = CS["ProfileDB"];
		var CurrentTask = ProfileDB.length;
		var SearchURL = CS["SearchURL"];
		var Data = {
			"TaskName": TaskName,
			"SearchURL": SearchURL,
			"TaskType": TaskType,
			"TargetAmount": TargetAmount,
			"Date": TodayDate,
			"Profiles": [],
			"TotalVisited": 0,
			"CurrentList": []
		};
		ProfileDB.push(Data);
		chrome.storage.local.set({
			"ProfileDB": ProfileDB,
			"SearchValue": "",
			"TaskType": TaskType,
			"BotStatus": "Processing"
		}, function() {
			chrome.extension.sendMessage({
				"Message": "StartTask",
				"TaskID": CurrentTask
			}, function(){
				ProgressPage();
				OpenTab("ProgressTab");
			});
		});
	});
	return false;
};
document.querySelector("[name=StartScanning]").onclick = function() {
	document.querySelector("[name=TaskType]").value = "Scan";
	document.querySelector("[name=Start]").click();
};

/* TASK PROGRESS PAGE */
AddInterval(function() {
	chrome.storage.local.get([
		"BotStatus",
		"ProfileDB",
		"TaskType",
		"TotalLiked",
		"CurrentTask"
	], function(CS) {
		if(CS["TaskType"] == "Like") {
			document.querySelectorAll(".ProgressTab > div")[0].style.display = "none";
			document.querySelectorAll(".ProgressTab > div")[1].style.display = "none";
			document.querySelectorAll(".ProgressTab [name=\"ResumeTask\"]")[0].style.display = "none";
			document.querySelectorAll(".ProgressTab > div")[2].innerHTML = "<div class=\"content-panel\">Total post(s) like: " + CS["TotalLiked"] + "</div>";
		}
		var Data = CS["ProfileDB"][CS["CurrentTask"]];
		if((CS["BotStatus"] == "Processing" || CS["BotStatus"] == "Paused") && CS["TaskType"] != "Like") {
			document.querySelector(".ProgressTab .TaskName").innerHTML = Data.TaskName;
			document.querySelector(".ProgressTab .TargetAmount").innerHTML = Data.TargetAmount;
			document.querySelector(".ProgressTab .VisitedAmount").innerHTML = Data.Profiles.length;
			document.querySelector(".ProgressTab .SkippedAmount").innerHTML = (Data.TotalVisited - Data.Profiles.length);
			document.querySelector(".ProgressTab .ProgressBar").innerHTML = ((Data.TotalVisited/Data.TargetAmount)*100).toFixed(2) + "%";
			document.querySelector(".ProgressTab .ProgressBar").style = "background-size: " + Number((Data.TotalVisited/Data.TargetAmount)*100) + "% 100%";
		}
	});
}, 1000);
function ProgressPage() {
	chrome.storage.local.get([
		"BotStatus",
		"ProcessingWindow",
		"TaskType",
		"TotalLiked"
	], function(CS) {
		if(CS["TaskType"] == "Like") {
			document.querySelectorAll(".ResultTab > div")[0].style.display = "none";
			document.querySelectorAll(".ResultTab > div")[1].style.display = "none";
			document.querySelectorAll(".ResultTab [name=\"ExportIT\"]")[0].style.display = "none";
			document.querySelectorAll(".ResultTab > div")[2].innerHTML = "<div class=\"content-panel\">Total post(s) like: " + CS["TotalLiked"] + "</div>";
		}
		if(CS["BotStatus"] == "Processing") {
			document.getElementsByName("PauseTask")[0].onclick = function() {
				chrome.storage.local.set({"BotStatus": "Paused"});
				ProgressPage();
				document.getElementsByName("ResumeTask")[0].style.display = "inline-block";
				document.getElementsByName("PauseTask")[0].style.display = "none";
				chrome.windows.get(Number(CS["ProcessingWindow"]), function(window) {
					if (window) {
						chrome.windows.remove(Number(CS["ProcessingWindow"]), function() {
							OpenTab("ResultTab");
						});
					} else {
						OpenTab("ResultTab");
					}
				});
			};
			document.getElementsByName("ResumeTask")[0].style.display = "none";
		}
		
		if(CS["BotStatus"] == "Paused") {
			document.getElementsByName("ResumeTask")[0].onclick = function() {
				var CurrentTask = CS["CurrentTask"];
				chrome.extension.sendMessage({
					"Message": "StartTask",
					"TaskID": CurrentTask
				});
				document.getElementsByName("ResumeTask")[0].style.display = "none";
				document.getElementsByName("PauseTask")[0].style.display = "inline-block";
			};
			document.getElementsByName("PauseTask")[0].style.display = "none";
		}

		document.getElementsByName("StopTask")[0].onclick = function() {
			chrome.storage.local.set({"BotStatus": "Done"});
			chrome.windows.get(Number(CS["ProcessingWindow"]), function(window) {
				if (window) {
					chrome.windows.remove(Number(CS["ProcessingWindow"]), function() {
						OpenTab("ResultTab");
					});
				} else {
					OpenTab("ResultTab");
				}
			});
		};
	});
}
ProgressPage();

/* START TO LIKE POSTS */
document.getElementsByName("Connections")[0].onfocus = function() {
	this.selectedIndex = -1;
};
document.getElementsByName("Connections")[0].onchange = function() {
	var Connections = document.getElementsByName("Connections")[0].value;
	chrome.storage.local.set({
		"BotStatus": "Processing",
		"TaskType": "Like",
		"TotalLiked": 0,
		"Connections": Connections
	}, function() {
		chrome.windows.create({
			url: "https://www.linkedin.com/feed/",
			state: "maximized",
			type: "popup",
			focused: true
		}, function(window) {
			/* SET WINDOW ID */
			var ProcessingWindow = window.id;
			var ProcessingTab = window.tabs[0].id;
			chrome.storage.local.set({
				"ProcessingWindow": ProcessingWindow,
				"ProcessingTab": ProcessingTab
			});
			chrome.tabs.executeScript(ProcessingTab, {
				file: "scripts/LikePosts.js"
			});
		});
		ProgressPage();
		OpenTab("ProgressTab");
	});
};

/* CONTENTS OF HOME PAGE */
document.getElementsByName("Home")[0].onclick = function() {
	chrome.storage.local.get([
		"BotStatus"
	], function(CS) {
		if(CS["BotStatus"] == "Processing") {
			OpenTab("ProgressTab");
		} else {
			OpenTab("HomePage");
		}
	});
};
AddInterval(function() {
	chrome.storage.local.get([
		"TodayVisits",
		"DailyVisitLimit",
		"UserType"
	], function(CS) {
		document.querySelector(".ProViewedToday").innerHTML = CS["TodayVisits"];
		document.querySelector(".ProViewLimit").innerHTML = CS["DailyVisitLimit"];
		if(CS["UserType"] == "FREE") document.querySelector(".UserTypeStatus").innerHTML = "(You're Not Premium Linkedin User)";
	});
}, 1000);
document.querySelector(".LinkedInSearch").onsubmit = function() {
	var SearchValue = this.SearchValue.value;
	if(isEmpty(SearchValue) || SearchValue.length < 3) {
		ShowMessage("ERROR", "Please enter at least 3 characters!");
	} else {
		chrome.tabs.create(
		{
			url: "https://www.linkedin.com/search/results/people/?keywords=" + SearchValue + "&origin=GLOBAL_SEARCH_HEADER",
			active: true
		});
	}
	return false;
};
document.querySelector(".TrendingContentSearch").onsubmit = function() {
	var SearchValue = this.SearchValue.value;
	if(isEmpty(SearchValue) || SearchValue.length < 3) {
		ShowMessage("ERROR", "Please enter at least 3 characters!");
	} else {
		/* START: AJAX */
		var getRequest = new XMLHttpRequest();
		getRequest.onload = function()
		{
			var Data = JSON.parse(this.responseText);
			var TrendingContents = document.querySelector(".TrendingContents");
				TrendingContents.innerHTML = "";
				TrendingContents.style.display = "block";
			for(var i=0; i<Data.matching_articles.length; i++) {
				var Content = document.createElement("div");
					Content.style = "margin-bottom: 7.5px; display: inline-block; width: 50%;";
					Content.innerHTML = "<div style=\"width: calc(100% - 10px);\"><img style=\"border: 1px solid #ced0d4; width:100%; height: 85px;\" src=\"" + Data.matching_articles[i].thumbnail_url + "\"/><span style=\"float: right; text-align: left; font-size: 12px; margin-right: 7.5px;\">" + Data.matching_articles[i].title + "<br/><span style=\"width: 100%;\"><a target=\"_blank\" href=\"" + Data.matching_articles[i].link + "\">Read more...</a><a target=\"_blank\" style=\"float: right;\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=" + Data.matching_articles[i].link + "&title=" + Data.matching_articles[i].title + "&ro=false&summary=&source=\">Share</a></span></span></div>";
				TrendingContents.appendChild(Content);
			}
		};
		
		var ViewBackPage = "http://api.trendspottr.com/v2.0/trendfeed?key=0ea3b410a500bf41820d3c6b228570ee&action=searchArticles&query_string=" + SearchValue + "&count=10";
		setCookie("TCSearchValue", SearchValue, 660);
		getRequest.open("GET", ViewBackPage);
		getRequest.send();
		/* END: AJAX */
	}
	return false;
};
if(getCookie("TCSearchValue")) {
	/* START: AJAX */
	var getRequest = new XMLHttpRequest();
	getRequest.onload = function()
	{
		var Data = JSON.parse(this.responseText);
		var TrendingContents = document.querySelector(".TrendingContents");
			TrendingContents.innerHTML = "";
			TrendingContents.style.display = "block";
		for(var i=0; i<Data.matching_articles.length; i++) {
			var Content = document.createElement("div");
				Content.style = "margin-bottom: 7.5px; display: inline-block; width: 50%;";
				Content.innerHTML = "<div style=\"width: calc(100% - 10px);\"><img style=\"border: 1px solid #ced0d4; width:100%; height: 85px;\" src=\"" + Data.matching_articles[i].thumbnail_url + "\"/><span style=\"float: right; text-align: left; font-size: 12px; margin-right: 7.5px;\">" + Data.matching_articles[i].title + "<br/><span style=\"width: 100%;\"><a target=\"_blank\" href=\"" + Data.matching_articles[i].link + "\">Read more...</a><a target=\"_blank\" style=\"float: right;\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=" + Data.matching_articles[i].link + "&title=" + Data.matching_articles[i].title + "&ro=false&summary=&source=\">Share</a></span></span></div>";
			TrendingContents.appendChild(Content);
		}
	};

	var ViewBackPage = "http://api.trendspottr.com/v2.0/trendfeed?key=0ea3b410a500bf41820d3c6b228570ee&action=searchArticles&query_string=" + getCookie("TCSearchValue") + "&count=10";
	getRequest.open("GET", ViewBackPage);
	getRequest.send();
	/* END: AJAX */
}

/* RESULT TAB */
AddInterval(function() {
	chrome.storage.local.get([
		"BotStatus",
		"ProfileDB",
		"TaskType",
		"CurrentTask"
	], function(CS) {
		var Data = CS["ProfileDB"][CS["CurrentTask"]];
		if(CS["BotStatus"] == "Done" && CS["TaskType"] != "Like") {
			document.querySelector("[name=ExportIT]").onclick = function() {
				ExportCSV(Data);
			};
			document.querySelector(".ResultTab .TaskName").innerHTML = Data.TaskName;
			document.querySelector(".ResultTab .TargetAmount").innerHTML = Data.TargetAmount;
			document.querySelector(".ResultTab .VisitedAmount").innerHTML = Data.Profiles.length;
			document.querySelector(".ResultTab .SkippedAmount").innerHTML = (Data.TotalVisited - Data.Profiles.length);
			document.querySelector(".ResultTab .ProgressBar").innerHTML = ((Data.TotalVisited/Data.TargetAmount)*100).toFixed(2) + "%";
			document.querySelector(".ResultTab .ProgressBar").style = "background-size: " + Number((Data.TotalVisited/Data.TargetAmount)*100) + "% 100%";
		}
	});
}, 1000);

/* POP UP ELEMENTS */
document.getElementsByName("TaskHistory")[0].onclick = function() {
	OpenTab("TaskHistory");
	TaskHistory();
};
document.getElementsByName("Settings")[0].onclick = function() {
	OpenTab("SettingsTab");
};
document.getElementsByName("TaskName")[0].onkeyup = function() {
	setCookie("CurrentTaskName", this.value, 0.05);
};

/* SETTINGS */
chrome.storage.local.get([
	"DailyVisitLimit",
	"SkipTime",
	"LikeStart",
	"LikeList"
], function(CS) {
	var DailyVisitLimitOptions = document.querySelectorAll("[name=DailyVisitLimit] option");
	for(var i=0; i<DailyVisitLimitOptions.length; i++) {
		if(DailyVisitLimitOptions[i].value == Number(CS["DailyVisitLimit"])) DailyVisitLimitOptions[i].setAttribute("selected", "");
	}
	var SkipTimeOptions = document.querySelectorAll("[name=SkipTime] option");
	for(var i=0; i<SkipTimeOptions.length; i++) {
		if(SkipTimeOptions[i].value == Number(CS["SkipTime"])) SkipTimeOptions[i].setAttribute("selected", "");
	}
	if(CS["LikeStart"] == "OnBrowserStart") document.getElementsByName("LikeStart")[0].setAttribute("checked", "");
	document.getElementsByName("LikeList")[0].value = CS["LikeList"];
});
document.getElementsByName("SaveSettings")[0].onclick = function() {
	var DailyVisitLimit = document.getElementsByName("DailyVisitLimit")[0].value;
	var SkipTime = document.getElementsByName("SkipTime")[0].value;
	
	var LikeStartCheckBox = document.getElementsByName("LikeStart")[0];
	if(LikeStartCheckBox.checked) var LikeStart = "OnBrowserStart";
	else var LikeStart = "NONE";
	var LikeList = document.getElementsByName("LikeList")[0].value;
	
	chrome.storage.local.set({
		"DailyVisitLimit": DailyVisitLimit,
		"SkipTime": SkipTime,
		"LikeStart": LikeStart,
		"LikeList": LikeList,
	});
	ShowMessage("SUCCESS", "Settings has been updated successfully!");
};

/* RESULT PAGE */
document.getElementsByName("Close")[0].onclick = function() {
	chrome.storage.local.set({
		"BotStatus": "INACTIVE"
	});
	OpenTab("HomePage");
};