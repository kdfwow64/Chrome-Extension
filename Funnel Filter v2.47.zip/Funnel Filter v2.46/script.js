/* START: FUNCTIONS */
function getURLParameter(name) {
	return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [null, ''])[1].replace(/\+/g, '%20')) || null;
}
/* END: FUNCTIONS */

/* CHECK USER TYPE */
function CheckUserType() {
	if(document.getElementsByClassName("nav-item__try-premium ember-view").length > 0) {
		chrome.storage.local.set({
			"DailyVisitLimit": 200,
			"UserType": "FREE"
		});
	} else {
		chrome.storage.local.set({
			"UserType": "PREMIUM"
		});
		chrome.storage.local.get([
			"DailyVisitLimit"
		], function(CS) {
			if(CS["DailyVisitLimit"] == 200) {
				chrome.storage.local.set({
					"DailyVisitLimit": 800
				});
			}
		});
	}
}
CheckUserType();

/* SET SEARCH URL AND VALUE IF IN SEARCH PAGE */
setInterval(function() {
	var PageURL = window.location.href;
	if(PageURL.search("linkedin.com/search") != -1) {
		var SearchValue = getURLParameter("keywords");
		var ResultFound = (document.querySelectorAll(".search-results__container .search-results__total").length > 0) ? document.querySelectorAll(".search-results__container .search-results__total")[0].innerText.replace(/[^0-9]/g, "") : 1000;
		chrome.storage.local.set({
			"SearchValue": SearchValue,
			"SearchURL": PageURL,
			"ResultFound": ResultFound
		});
	}
}, 1000);

/* SET SEARCH URL AND VALUE IF IN SALES NAV SEARCH PAGE */
setInterval(function() {
	var PageURL = window.location.href;
	if(PageURL.search("linkedin.com/sales/search") != -1) {
		var SearchValue = (document.querySelector(".results-header .selected-filters-list")) ? document.querySelector(".results-header .selected-filters-list").innerText.trim() : "";
		if(document.querySelector(".results-header .selected .spotlight-result-count")) ResultFound = (Number(document.querySelector(".results-header .selected .spotlight-result-count").innerText)) ? document.querySelector(".results-header .selected .spotlight-result-count").innerText : 1000;
		else ResultFound = 1000;
		chrome.storage.local.set({
			"SearchValue": SearchValue,
			"SearchURL": PageURL,
			"ResultFound": ResultFound
		});
	}
}, 1000);

/* UPDATE AUTO LIKE LIST */
function LikeListUpdate() {
	var ProfileActions = document.querySelectorAll("div.pv-top-card-section__body > div.pv-top-card-section__actions");
	var MessageButton = document.querySelectorAll("div.pv-top-card-section__body > div.pv-top-card-section__actions [data-control-name=\"message\"]");
	if(ProfileActions[0] && MessageButton[0]) {
		var PageURL = window.location.href;
		if(PageURL.search(".linkedin.com/in") != -1) {
			chrome.storage.local.get([
				"LikeList"
			], function(CS) {
				var Action = document.createElement("button");
					Action.className = "message-anywhere-button message primary top-card-action link-without-visited-state";
				if((CS["LikeList"]).search(PageURL.split("/")[4]) != -1) {
					Action.innerHTML = "Remove From Like List";
					Action.setAttribute("like-list-action", "Remove");
				} else {
					Action.innerHTML = "Add To Like List";
					Action.setAttribute("like-list-action", "Add");
				}
				Action.onclick = function() {
					var ProfileID = (window.location.href).split("/")[4];
					if(Action.getAttribute("like-list-action") == "Remove") {
						var LikeList = (CS["LikeList"]).split(",");
						var NewLikeList = "";
						for(var i=0; i<LikeList.length; i++) {
							if(LikeList[i].trim() != ProfileID) NewLikeList = NewLikeList + LikeList[i].trim() + ", ";
						}
						chrome.storage.local.set({
							"LikeList": NewLikeList
						}, function() { 
							Action.innerHTML = "Add To Like List";
							Action.setAttribute("like-list-action", "Add");
						});
					} else {
						var NewLikeList = CS["LikeList"] + ProfileID + ", ";
						chrome.storage.local.set({
							"LikeList": NewLikeList
						}, function() {
							Action.innerHTML = "Remove From Like List";
							Action.setAttribute("like-list-action", "Remove");
						});
					}
				};
				ProfileActions[0].appendChild(Action);
			});
		}
	}
}

setInterval(function() {
	var MessageButton = document.querySelectorAll("div.pv-top-card-section__body > div.pv-top-card-section__actions [data-control-name=\"message\"]");
	var LikeListUpdater = document.querySelectorAll("div.pv-top-card-section__body > div.pv-top-card-section__actions [like-list-action]");
	if(!MessageButton[0] && LikeListUpdater[0]) {
		LikeListUpdater[0].outerHTML = "";
	}
	if(MessageButton[0] && !LikeListUpdater[0]) {
		LikeListUpdate();
	}
}, 1000);